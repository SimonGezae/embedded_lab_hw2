import Rpi.GPIO as GPIO
import time

#set pins for leds
LedPins = [17, 18, 27, 22, 23, 24, 25, 12]

def print_message():
    print("============program runnning========")
    print("press ctrl+c to end the program")
    print("Please enter to begin\n")

def setup():
    #set the gpio to BCM numbering
    GPIO.setmode(GPIO.BCM)
    #set all ledpin's mode to output& initial level to high
    GPIO.setup(LedPins, GPIO.OUT, initial=GPIO.HIGH)

def main():
    print_message()
    
    while True:
        for i in range(4):
            GPIO.output(LedPins[3-i], GPIO.LOW)
            
            GPIO.output(LedPins[4+i], GPIO.LOW)
            time.sleep(1)
            GPIO.output(LedPins[3-i], GPIO.HIGH)
            GPIO.output(LedPins[4+i], GPIO.HIGH)
        
        for i in range(2):
            GPIO.output(LedPins[i+1], GPIO.LOW)
            GPIO.output(LedPins[6-i], GPIO.LOW)
            time.sleep(1)
            GPIO.output(LedPins[i+1], GPIO.HIGH)
            GPIO.output(LedPins[6-i], GPIO.HIGH)

def destroy():
    GPIO.output(LedPins, GPIO.HIGH)
    GPIO.cleanup()

if __name__ == "__main__":
    setup()
    try:
        main()
    except KeyboardInterrupt:
        destroy()

